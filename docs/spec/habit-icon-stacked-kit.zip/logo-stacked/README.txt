Habit app icon - stacked days
Three day-cards in a pile, the front one checked: each finished day adds to the stack.
Two versions: LIGHT (pale green tile, dark green front card) and DARK (deep green tile, white front card).

Colours (app design tokens)
 Light: tile #F0F4EF -> #E7F4E7; cards #A9D8AB (back), #5CAC60 (middle), #246538 (front); check #FFFFFF
 Dark:  tile #2F7B45 -> #1C4F2C; cards #E7F4E7 (back), #8BD799 (middle), #FFFFFF (front); check #2F7B45

Files (per version)
 habit-icon-*-master.svg / .pdf  editable master, layers: background, cards > card-back, card-middle, card-front, check
                                 Illustrator and Affinity open them editable; Photoshop opens them as a vector smart object.
 habit-icon-*-fullbleed.svg      square, no rounding (launchers and stores round it)
 app-icon-*-1024.png, play-store-icon-*-512.png
 android-*-adaptive-background.svg / -foreground.svg   adaptive icon layers, cards inside the 66dp safe zone
Shared
 android-adaptive-monochrome.svg  Android 13+ themed icon (cards in three alpha levels, check cut out)
 android-notification-icon.svg    status-bar silhouette (Android tints it)
 habit-mark-on-white.svg          the cards alone for white backgrounds (download page, splash)
